﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace csvtojson
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            int counter = 1;
            string[] strheader = new string[100];
            string json = "[\n";
            foreach(string line in File.ReadLines("file.csv"))
            {
                if (counter == 1)
                {
                    strheader = line.Split(',');
                }
                else
                {
                    json = json + "{";
                    string[] values = line.Split(',');
                    int i = 0;
                    foreach (string value in values)
                    {
                        json = json + "\"" + strheader[i] + "\":\"" + value + "\",";
                        i = i + 1;
                    }
                    json = json.Remove(json.Length - 1);
                    json = json + "}\n,";
                }
                counter++;
            }
            json = json.Remove(json.Length - 1);
            json = json + "]";
            File.WriteAllText("filejson.json", json);
            MessageBox.Show("completed");
        }
    }
}
